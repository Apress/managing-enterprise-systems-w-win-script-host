
Any script from this chapter that requires a domain name will require modification.

The BAConv binary to array conversion component requires VB5 runtime. The VB code and project 
files are included if any modifications are required or a recompilation using a different version
of VB.