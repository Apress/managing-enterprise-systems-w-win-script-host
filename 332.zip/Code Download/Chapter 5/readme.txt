
Edir examples under solution 5.11 list arguments in wrong order. 
The following lists the correct command line sample:
edir "d:\users" "Size > 500000 And modified<#1/1/99#" 
edir "d:\users" "Size > 500000" "\.doc$"