
The GetFolderObj function listed in Solution 12.18,CreateFolder function listed
in Solution 12.20 and GetAddressObj from Solution 12.25 are stored in the maillib.vbs file.

The solution script for problem 12.22 is labeled as copymove.wsf, but there is already
a copymove.wsf script from solution 12.21, so it stored as sol12-22.wsf