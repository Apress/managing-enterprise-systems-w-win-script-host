
There's an error for solution 15.2 the line
WebSet objWebService = GetObject("IIS://Thor/W3SVC")
should be
Set objWebService = GetObject("IIS://Thor/W3SVC")